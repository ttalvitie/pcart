library(testthat)
library(rpcart)

test_check("rpcart")
